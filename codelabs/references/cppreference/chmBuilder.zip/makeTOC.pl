# generate the Table of Contents.hhc file

# output the header

print <<EOS;
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1">
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<OBJECT type="text/site properties">
	<param name="ImageType" value="Folder">
</OBJECT>
<UL>
EOS

@fileList = split /\n/, `find -iname index.html -o -iname all_c*_functions.html`;

for $file (@fileList)
{
	next if ($file =~ /^\.\\index.html/i);	# don't process the main index file

	open IN, $file or die "Can't open input $file: $!\n";
	
	$file =~ /^(.+\\)/;
	$directory = $1;
	
	while (<IN>)
	{
		if (m!<title>(.+)</title>!i)
		{
			$title = $1;
		
			print <<EOS;
	<LI> <OBJECT type="text/sitemap">
		<param name="Name" value="$title">
		<param name="Local" value="$file">
		</OBJECT>
	<UL>
EOS
		}
		
		# gather the entire row into one string
		#<tr class="category-table-tr-2">
		#	<td class="category-table-td"><a href=
		#	"cppbitset/bitset_constructors.html">Bitset Constructors</a> (C++
		#	Bitsets)</td>
		#	<td class="category-table-td">create new bitsets</td>
		#</tr>
		if (m!<tr class="category-table-tr-\d">!i)
		{
			$line = $_;
			while ($line !~ m!</tr>!i)
			{
				$line .= <IN>;
			}
			
			# eliminate all returns & following whitespace
			$line =~ s/\n\s*/ /g;
			
			# parse out the data
			if ($line =~ m!<td class="category-table-td">(.+)</td>.*<td class="category-table-td">(.+)</td>!i)
			{
				$name = $1;
				$desc = $2;
				
				# extract the file to link to
				$name =~ m!<a +href= *"(.+?)">!i;
				$path = $directory . $1;
				
				# remove all HTML tags from name and description
				$name =~ s!<.+?>!!ig;
				$desc =~ s!<.+?>!!ig;
				
				# output the entry
				print <<EOS;
		<LI> <OBJECT type="text/sitemap">
			<param name="Name" value="$name - $desc">
			<param name="Local" value="$path">
			</OBJECT>
EOS
			}
			else
			{
				die "Can't parse category-table-td from '$line'\n";
			}
		}
	}
	
	close IN;
	
	# close the UL for this file
	print "\t</UL>\n\n";
}

	
# output the footer
print <<EOS;
</UL>
</BODY></HTML>
EOS
