# strip google analytics junk

#<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
#</script>
#<script type="text/javascript">
#_uacct = "UA-2828341-1";
#urchinTracker();
#</script>

$count = 0;

while (<>)
{
	$count = 2 if (/www.google-analytics.com/i);

	if ($count && m!</script>!i)
	{
		$count--;
		next;
	}
	
	next if ($count > 0);
	
	print;
}