# create the Index.hhk file

# print the header for the index
print <<EOS;
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
<meta name="GENERATOR" content="Microsoft&reg; HTML Help Workshop 4.1">
<!-- Sitemap 1.0 -->
</HEAD><BODY>
<UL>
EOS

@fileList = split /\n/, `find . -iname *.html`;

for $file (@fileList)
{
	open IN, $file or die "Can't open input $file: $!\n";
	
	while (<IN>)
	{
	
		if (m!<title>(.+)</title>!i)
		{
			$title = $1;
			print <<EOS;
	<LI> <OBJECT type="text/sitemap">
		<param name="Name" value="$title">
		<param name="Local" value="$file">
		</OBJECT>
EOS
			last;
		}
	}
	close IN;
}
# print the footer for the index
print <<EOS;
</UL>
</BODY></HTML>
EOS
