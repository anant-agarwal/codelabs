chmBuilder - A tool set to convert cppreference to MS HTML help (CHM) format

Installation
------------

If you just want the CHM file, simply unpack only the cppref.chm file from the archive.  You can ignore the rest of this
document.  If you want to rebuild the CHM file or make changes, then keep reading ...

Download the archived version of cppreference.com (see the FAQ page) and unpack into a directory of your choice.

Unpack this archive into the same directory where you have the cppreference archive from above.

In addition to the above, you must also have the Microsoft HTML Help Compiler.  Either google for it or try
	http://msdn2.microsoft.com/en-us/library/ms669985.aspx

You will also need a working version of the unix 'find' tool.  There are several windows ports of this tool.  
One is available from the GNUWin32 project
	http://gnuwin32.sourceforge.net/packages/findutils.htm

You will also need a working copy of perl.  I prefer the ActiveState version, but any working perl will do.
Download the ActiveState version from
	http://www.activestate.com/Products/activeperl/


Usage
-----

In the directory where you have the archive, run the three perl scripts as follows:
	find . -iname *.html -exec perl -i.bak stripgoogle.pl {} ;
	perl makeIndex.pl > Index.hhk
	perl makeTOC.pl > "Table of Contents.hhc"

Now you can load the html help project into Microsoft HTML Help Compiler.  Load the following file:
	cppref.hhp


Script Descriptions
-------------------

I wrote some perl scripts to assist in converting the www.cppreference.com site into MS html help format.

There are three perl scripts which are used as described below.

stripgoogle.com - this script removes the google analytics code from each page in the site.  The CHM interpreter is
unable to process the files when the analytics code is present.

Usage:
	find . -iname *.html -exec perl -i.bak stripgoogle.pl {} ;
	del *.bak /s



makeIndex.pl - this script creates the Index.hhk file that is needed by the MS html help compiler

Usage:
	perl makeIndex.pl > Index.hhk
	
This tool is dependant on having a copy of 'find' in the path.



makeTOC.pl - this script creates the Table of Contents.hhc file needed by the MS html help compiler

Usage:
	perl makeTOC.pl > "Table of Contents.hhc"
	
This tool depends on having a copy of 'find' in the path.  It is also quite dependant on the format of the html that
is generated for cppreference.com.  It looks for specific styles and html tags in the code to extract the necessary
information to generate the TOC.